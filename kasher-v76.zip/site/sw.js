// Service worker — makes the app open and work with no internet
const CACHE = 'kasher-pro-v76';
const CORE = ['./', './index.html', './admin.html', './config.js', './manifest.json', './icon-48.png', './icon-192.png', './icon-512.png', './icon-maskable-192.png', './icon-maskable-512.png', './apple-touch-icon.png'];

// A response that came through a redirect cannot be used for a page load
// (the browser shows ERR_FAILED), so store a clean copy instead.
async function clean(res) {
  if (!res || !res.redirected) return res;
  const body = await res.blob();
  return new Response(body, { status: res.status, statusText: res.statusText, headers: res.headers });
}

self.addEventListener('install', e => {
  e.waitUntil((async () => {
    const cache = await caches.open(CACHE);
    await Promise.all(CORE.map(async u => {
      try { const r = await fetch(u, { cache: 'reload' }); if (r.ok) await cache.put(u, await clean(r)); } catch (err) {}
    }));
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', e => {
  e.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)));
    await self.clients.claim();
  })());
});

const offlinePage = () => new Response(
  '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width"><body style="font-family:sans-serif;text-align:center;padding:40px;direction:rtl"><h2>ئینتەرنێت نییە</h2><p>یەکەم جار پێویستە ئەپەکە بە ئینتەرنێت بکرێتەوە. دواتر بێ ئینتەرنێت کار دەکات.</p><button onclick="location.reload()" style="padding:12px 24px;font-size:16px">دووبارە هەوڵبدەرەوە</button></body>',
  { headers: { 'Content-Type': 'text/html; charset=utf-8' } });

self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);

  // Page loads: internet first (always newest version), saved copy when offline
  if (req.mode === 'navigate') {
    e.respondWith((async () => {
      const cache = await caches.open(CACHE);
      const key = url.pathname.endsWith('admin.html') ? './admin.html' : './index.html';
      try {
        const res = await fetch(req);
        if (res.ok) { const c = await clean(res.clone()); cache.put(key, c); }
        return await clean(res);
      } catch (err) {
        return (await cache.match(key)) || (await cache.match('./')) || offlinePage();
      }
    })());
    return;
  }

  const cacheable =
    url.origin === location.origin ||
    (url.hostname === 'www.gstatic.com' && url.pathname.startsWith('/firebasejs/')) ||
    url.hostname === 'fonts.googleapis.com' ||
    url.hostname === 'fonts.gstatic.com' ||
    (url.hostname === 'cdn.jsdelivr.net' && (url.pathname.startsWith('/npm/html5-qrcode') || url.pathname.startsWith('/npm/xlsx@') || url.pathname.startsWith('/npm/qrcode-generator@')));
  if (!cacheable) return; // Firebase database/auth traffic is never touched

  // Files: saved copy first (fast), refreshed in the background
  e.respondWith((async () => {
    const cache = await caches.open(CACHE);
    const hit = await cache.match(req, { ignoreSearch: url.origin === location.origin });
    const net = fetch(req).then(async res => {
      if (res && (res.ok || res.type === 'opaque')) cache.put(req, await clean(res.clone()));
      return res;
    }).catch(() => null);
    return hit || (await net) || new Response('', { status: 504 });
  })());
});

// owner alert: tapping the notification opens the app
self.addEventListener('notificationclick', e => {
  e.notification.close();
  e.waitUntil(clients.matchAll({ type: 'window', includeUncontrolled: true }).then(l => {
    for (const c of l) if ('focus' in c) return c.focus();
    return clients.openWindow('./');
  }));
});

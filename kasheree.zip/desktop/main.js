const { app, BrowserWindow, session, shell, Menu } = require('electron');
const START = 'https://__HOST____PATH__/index.html';
const ORIGIN = new URL(START).origin;
const inside = u => { try { return new URL(u).origin === ORIGIN; } catch { return false; } };

if (!app.requestSingleInstanceLock()) app.quit();
let win;
function create() {
  win = new BrowserWindow({
    width: 1300, height: 820, minWidth: 380, minHeight: 500,
    title: 'کاشێر پرۆ', backgroundColor: '#ffffff', autoHideMenuBar: true,
    webPreferences: { contextIsolation: true, spellcheck: false }
  });
  win.maximize();
  win.loadURL(START);
  // WhatsApp and other outside links open in the normal browser
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (inside(url) || url === 'about:blank') return { action: 'allow', overrideBrowserWindowOptions: { autoHideMenuBar: true } };
    shell.openExternal(url); return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (e, url) => { if (!inside(url)) { e.preventDefault(); shell.openExternal(url); } });
  win.webContents.on('before-input-event', (e, i) => {
    if (i.type !== 'keyDown') return;
    if (i.key === 'F5' || (i.control && i.key.toLowerCase() === 'r')) { win.webContents.reload(); e.preventDefault(); }
    else if (i.key === 'F11') { win.setFullScreen(!win.isFullScreen()); e.preventDefault(); }
    else if (i.control && (i.key === '=' || i.key === '+')) { win.webContents.setZoomLevel(win.webContents.getZoomLevel() + 0.5); e.preventDefault(); }
    else if (i.control && i.key === '-') { win.webContents.setZoomLevel(win.webContents.getZoomLevel() - 0.5); e.preventDefault(); }
    else if (i.control && i.key === '0') { win.webContents.setZoomLevel(0); e.preventDefault(); }
  });
}
app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
app.whenReady().then(() => {
  Menu.setApplicationMenu(null);
  const ok = ['media', 'clipboard-read', 'clipboard-sanitized-write', 'notifications', 'fullscreen'];
  session.defaultSession.setPermissionRequestHandler((wc, p, cb) => cb(ok.includes(p)));
  session.defaultSession.setPermissionCheckHandler((wc, p) => ok.includes(p));
  create();
});
app.on('window-all-closed', () => app.quit());

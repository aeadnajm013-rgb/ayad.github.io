package com.kasherpro.app;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Message;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

/** Kasher Pro: the web app full-screen inside the phone's WebView (no address bar). */
public class MainActivity extends Activity {
    private static final int REQ_FILE = 2, REQ_CAMERA = 1, REQ_SHOT = 3, REQ_CAMERA_SHOT = 4;
    private Uri shotUri;
    private WebView web;
    private String host;
    private ValueCallback<Uri[]> fileCallback;
    private PermissionRequest pendingPermission;

    // print() → Android print dialog; <a download> blobs → saved to Downloads
    private static final String INJECT =
        "(function(){if(window.__kp)return;window.__kp=1;" +
        "window.print=function(){KasherApp.print();};" +
        "var rv=URL.revokeObjectURL.bind(URL);URL.revokeObjectURL=function(u){setTimeout(function(){rv(u);},120000);};" +
        "function send(a){var h=a.href;fetch(h).then(function(r){return r.blob();}).then(function(b){var f=new FileReader();" +
        "f.onload=function(){KasherApp.save(a.download||'file',b.type||'application/octet-stream',String(f.result).split(',')[1]||'');};f.readAsDataURL(b);});}" +
        "var oc=HTMLAnchorElement.prototype.click;HTMLAnchorElement.prototype.click=function(){" +
        "if(this.hasAttribute('download')&&/^(blob:|data:)/.test(this.href)){send(this);return;}return oc.call(this);};" +
        "document.addEventListener('click',function(e){var a=e.target&&e.target.closest&&e.target.closest('a[download]');" +
        "if(a&&/^(blob:|data:)/.test(a.href)){e.preventDefault();e.stopPropagation();send(a);}},true);" +
        "})();";

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        host = getString(R.string.app_host);
        web = new WebView(this);
        web.setBackgroundColor(Color.WHITE);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setAllowFileAccess(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setTextZoom(100);
        s.setUserAgentString(s.getUserAgentString() + " KasherProApp");
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);
        web.addJavascriptInterface(new Bridge(), "KasherApp");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (inside(u)) return false;
                openOutside(u);
                return true;
            }
            @Override
            public void onPageStarted(WebView v, String url, Bitmap icon) { v.evaluateJavascript(INJECT, null); }
            @Override
            public void onPageFinished(WebView v, String url) { v.evaluateJavascript(INJECT, null); }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest req) {
                runOnUiThread(() -> {
                    if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        req.grant(req.getResources());
                    } else {
                        pendingPermission = req;
                        requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
                    }
                });
            }
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                // <input capture> → open the phone camera straight away
                if (p.isCaptureEnabled() && wantsImage(p.getAcceptTypes())) {
                    if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) takePhoto();
                    else requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA_SHOT);
                    return true;
                }
                try {
                    Intent i = p.createIntent();
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    startActivityForResult(i, REQ_FILE);
                } catch (ActivityNotFoundException e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }
            @Override
            public boolean onCreateWindow(WebView view, boolean dialog, boolean gesture, Message msg) {
                // window.open / target=_blank: WhatsApp etc. go outside, our own pages stay here
                WebView tmp = new WebView(MainActivity.this);
                tmp.setWebViewClient(new WebViewClient() {
                    @Override
                    public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                        Uri u = r.getUrl();
                        if (inside(u)) web.loadUrl(u.toString()); else openOutside(u);
                        v.destroy();
                        return true;
                    }
                });
                ((WebView.WebViewTransport) msg.obj).setWebView(tmp);
                msg.sendToTarget();
                return true;
            }
        });

        web.setDownloadListener((url, ua, cd, mime, len) -> {
            if (url.startsWith("http")) openOutside(Uri.parse(url));
        });

        if (state != null) web.restoreState(state);
        else web.loadUrl(getString(R.string.launch_url));
    }

    private static boolean wantsImage(String[] types) {
        if (types == null || types.length == 0) return true;
        for (String t : types) if (t == null || t.isEmpty() || t.startsWith("image")) return true;
        return false;
    }

    private void takePhoto() {
        try {
            File dir = new File(getCacheDir(), "cam");
            dir.mkdirs();
            File f = new File(dir, "photo_" + System.currentTimeMillis() + ".jpg");
            shotUri = FileProvider.getUriForFile(this, getPackageName() + ".files", f);
            Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            i.putExtra(MediaStore.EXTRA_OUTPUT, shotUri);
            i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(i, REQ_SHOT);
        } catch (Exception e) {
            if (fileCallback != null) { fileCallback.onReceiveValue(null); fileCallback = null; }
            Toast.makeText(this, "⚠️ " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private boolean inside(Uri u) {
        String h = u.getHost();
        return "https".equals(u.getScheme()) && h != null && h.equalsIgnoreCase(host);
    }

    private void openOutside(Uri u) {
        try {
            Intent i = u.getScheme() != null && u.getScheme().equals("intent")
                ? Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME)
                : new Intent(Intent.ACTION_VIEW, u);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "⚠️ " + u.getScheme(), Toast.LENGTH_SHORT).show();
        }
    }

    private class Bridge {
        @JavascriptInterface
        public void print() {
            runOnUiThread(() -> {
                PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
                if (pm != null) pm.print("Kasher Pro", web.createPrintDocumentAdapter("KasherPro"), new PrintAttributes.Builder().build());
            });
        }

        @JavascriptInterface
        public void save(String name, String mime, String b64) {
            try {
                byte[] data = Base64.decode(b64, Base64.DEFAULT);
                String safe = name.replaceAll("[\\\\/:*?\"<>|]", "_");
                OutputStream out;
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.MediaColumns.DISPLAY_NAME, safe);
                    v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                    v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                    out = getContentResolver().openOutputStream(uri);
                } else {
                    File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                    out = new FileOutputStream(new File(dir, safe));
                }
                out.write(data);
                out.close();
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "✅ Downloads: " + safe, Toast.LENGTH_LONG).show());
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "⚠️ " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        if (code == REQ_CAMERA_SHOT) {
            if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) takePhoto();
            else if (fileCallback != null) { fileCallback.onReceiveValue(null); fileCallback = null; }
            return;
        }
        if (code == REQ_CAMERA && pendingPermission != null) {
            if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) pendingPermission.grant(pendingPermission.getResources());
            else pendingPermission.deny();
            pendingPermission = null;
        }
    }

    @Override
    protected void onActivityResult(int code, int result, Intent data) {
        if (code == REQ_SHOT) {
            if (fileCallback != null) {
                fileCallback.onReceiveValue(result == RESULT_OK && shotUri != null ? new Uri[]{shotUri} : null);
                fileCallback = null;
            }
            return;
        }
        if (code == REQ_FILE && fileCallback != null) {
            fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result, data));
            fileCallback = null;
            return;
        }
        super.onActivityResult(code, result, data);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else moveTaskToBack(true);
    }

    @Override
    protected void onSaveInstanceState(Bundle out) { super.onSaveInstanceState(out); web.saveState(out); }

    @Override
    protected void onResume() { super.onResume(); web.onResume(); }

    @Override
    protected void onPause() { web.onPause(); CookieManager.getInstance().flush(); super.onPause(); }
}

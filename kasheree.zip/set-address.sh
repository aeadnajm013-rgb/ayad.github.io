#!/bin/bash
# Puts this site's address (owner.github.io[/repo]) into the Android and Windows projects.
cd "$(dirname "$0")"
OWNER=$(echo "$GITHUB_REPOSITORY_OWNER" | tr 'A-Z' 'a-z')
REPO="${GITHUB_REPOSITORY#*/}"
HOST="$OWNER.github.io"
if [ "$(echo "$REPO" | tr 'A-Z' 'a-z')" = "$HOST" ]; then P=""; else P="/$REPO"; fi
echo "Site: https://$HOST$P/"
for f in android/app/src/main/res/values/strings.xml desktop/main.js; do
  sed -i "s#__HOST__#$HOST#g; s#__PATH__#$P#g" "$f"
done
grep -h "github.io" android/app/src/main/res/values/strings.xml desktop/main.js | head -3
